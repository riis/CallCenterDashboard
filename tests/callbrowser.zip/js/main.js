/**
 * Listens for the app launching then creates the window
 *
 * @see http://developer.chrome.com/apps/app.window.html
 */

chrome.app.runtime.onLaunched.addListener(function () {
	chrome.app.window.create('index.html', {
		frame: "none",
		minWidth: 300,
		minHeight: 200,
		left : Math.round(screen.width * 0.075), // (1 - .percent) / 2, so that it's centered
		top : Math.round((screen.height * 0.1) / 4), //bias the position up a bit on the screen because of the task bar
		width : Math.round(screen.width * 0.85),
		height : Math.round(screen.height * .85)
	});
});
