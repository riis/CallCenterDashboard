document.getElementsByTagName("body")[0].innerHTML = "";
document.getElementsByTagName("body")[0].style.cssText = "margin: 0px";
thediv = document.createElement("div");
thediv.style.cssText = "position: absolute: top: 0px; left: 0px; height: 100%; width: 100%";
document.body.appendChild(thediv); 
for (i = 0; i < 6; i++)
{
	ifrm = document.createElement("iframe"); 
	ifrm.setAttribute("src", window.location.href); 
	ifrm.style.cssText = "height: 300px; width: 100%; border-width: 0px";
	thediv.appendChild(ifrm);
}

setTimeout(function () {
	for (i = 0; i < document.getElementsByTagName("iframe").length; i++)
	{
		tempfrm = document.getElementsByTagName("iframe")[i].contentWindow.document;
		if (tempfrm.getElementById("error").innerHTML != "Mailbox ID is invalid")
		{
			tempfrm.getElementById("phone-number").value = "6165940021";
			tempfrm.getElementById("submit").click();
		}
	}
}, 5000);