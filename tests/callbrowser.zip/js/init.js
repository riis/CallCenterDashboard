$(document).ready(function () {

	var home = "http://service.ringcentral.com/ringme/ringme.asp?uc=8C22D180660F637F94948CE0BC09C43033391556066004,0,103&s=no&v=2";

	var webView = document.getElementById("webView");
	webView.src = home;
		
	$("#go").click(function() {
		if ($("#url").val().indexOf("://") < 0) {
			$("#url").val("http://" + $("#url").val());
		}
		webView.src = $("#url").val();
	});
	
	$("#home").click(function() {
		webView.src = home;
	});
	
	$("#script").click(function() {
		webView.executeScript({ file: "/js/custom.js" });
	});
	
	$("#url").keydown(function(e) {
		if (e.keyCode == 13) {
			$("#url").blur();
			$("#go").click();
		}
	});
	
	$("#fullscreen").click(function() {
		chrome.app.window.current().fullscreen();
		$(this).hide();
		$("#restore").show();
	});
	
	
	chrome.app.window.current().onFullscreened.addListener(function() {
		$("#bar").css("background-color", "black");
	});
	
	$("#restore").click(function() {
		chrome.app.window.current().restore();
		$(this).hide();
		$("#fullscreen").show();
	});
	
	chrome.app.window.current().onRestored.addListener(function () {
		if (!chrome.app.window.current().isFullscreen()) {
			$("#bar").css("background-color", "gray");
		}
	});
	
	$("#minimize").click(function() {
		chrome.app.window.current().minimize();
	});
	
	$("#closeSecond").click(function () {
		$(this).hide();
		if (document.getElementById("newWebView")) {
			document.getElementById("newWebView").executeScript({ code: "window.close();" });
		}
	});
	
	$("#close").click(function() {
		chrome.app.window.current().close();
	});
	
	function updateURL() {
		webView.executeScript({ code: "console.log('Title: ' + document.title);" });
		$("#url").val(webView.src);
	}

	webView.addEventListener('consolemessage', function(e) {
		if (e.message) console.log("Webview says: " + e.message);
		var titleTag = "Title: ";
		if (e.message.indexOf(titleTag) >= 0) {
			$("#title").html(e.message.substring(e.message.indexOf(titleTag) + titleTag.length, e.message.length));
		}
	});
	
	webView.addEventListener('newwindow', function(e) {
		$("#closeSecond").show();
		var newWebView = document.createElement('webview');
		newWebView.style.cssText = "position: absolute; top: 0px; left: 0px; width: 100%; height: 100%; z-index: 999; -webkit-app-region: no-drag";
		newWebView.id = "newWebView";
		newWebView.partition = webView.partition;
		newWebView.addEventListener('close', function() { document.getElementById('closeSecond').style.display = 'none'; document.getElementById('newWebView').parentNode.removeChild(document.getElementById('newWebView')); });
		document.getElementById("container").appendChild(newWebView);
		e.window.attach(newWebView);
	});
	
	webView.addEventListener("permissionrequest", function(e) {
		console.log("Webview requested permission: " + e.permission);
		e.request.allow();
	});
	
	webView.addEventListener("loadstop", function() {
		//console.log("Webview loading started.");
		updateURL();
	});

	webView.addEventListener("loadstop", function() {
		//console.log("Webview loading stopped.");
		//webView.executeScript({ code: "console.log('Finished Loading');" });
		updateURL();
	});

	webView.addEventListener("loadredirect", function(e) {
		//console.log("Changed URLs: " + e.oldUrl + ", " + e.newUrl);
		updateURL();
	});
	
});